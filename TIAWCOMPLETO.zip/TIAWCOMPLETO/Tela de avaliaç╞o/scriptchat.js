// script.js
document.addEventListener('DOMContentLoaded', function() {
    const contacts = ['Thiago', 'Christiano', 'Yalle' ,'Ámalia' , 'Leonardo', 'Wendell', 'Allan'];
    const contactList = document.getElementById('contact-list');
    const chatWith = document.getElementById('chat-with');
    const chatMessages = document.getElementById('chat-messages');
    const messageInput = document.getElementById('message-input');
    const sendButton = document.getElementById('send-button');
    let currentContact = null;

    
    contacts.forEach(contact => {
        const li = document.createElement('li');
        li.textContent = contact;
        li.addEventListener('click', () => selectContact(contact));
        contactList.appendChild(li);
    });

    
    function selectContact(contact) {
        currentContact = contact;
        chatWith.textContent = `Chat com ${contact}`;
        loadMessages(contact);
    }

    
    function loadMessages(contact) {
        chatMessages.innerHTML = '';
        const messages = JSON.parse(localStorage.getItem(contact)) || [];
        messages.forEach(msg => {
            const div = document.createElement('div');
            div.textContent = msg;
            chatMessages.appendChild(div);
        });
    }

    
    sendButton.addEventListener('click', () => {
        const message = messageInput.value.trim();
        if (message && currentContact) {
            const messages = JSON.parse(localStorage.getItem(currentContact)) || [];
            messages.push(message);
            localStorage.setItem(currentContact, JSON.stringify(messages));
            const div = document.createElement('div');
            div.textContent = message;
            chatMessages.appendChild(div);
            messageInput.value = '';
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }
    });
});
