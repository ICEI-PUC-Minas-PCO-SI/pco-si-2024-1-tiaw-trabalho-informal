document.addEventListener('DOMContentLoaded', function () {
    const stars = document.querySelectorAll('.avaliacao li');
    const messageInput = document.getElementById('message-input');

    
    const savedRating = localStorage.getItem('rating');
    const savedComment = localStorage.getItem('comentario');

    if (savedRating) {
        stars.forEach(star => {
            if (star.getAttribute('data-avaliacao') === savedRating) {
                star.classList.add('ativo');
            } else {
                star.classList.remove('ativo');
            }
        });
    }

    if (savedComment) {
        messageInput.value = savedComment;
    }

    
    stars.forEach(star => {
        star.addEventListener('click', function (e) {
            const clickedStar = e.target;

            
            stars.forEach(star => {
                star.classList.remove('ativo');
            });

            
            clickedStar.classList.add('ativo');

            
            localStorage.setItem('rating', clickedStar.getAttribute('data-avaliacao'));
        });
    });
});

function sendMessage() {
    const messageInput = document.getElementById('message-input');

    
    localStorage.setItem('comentario', messageInput.value);

    
    alert('Avaliação e comentário enviados!');
}
