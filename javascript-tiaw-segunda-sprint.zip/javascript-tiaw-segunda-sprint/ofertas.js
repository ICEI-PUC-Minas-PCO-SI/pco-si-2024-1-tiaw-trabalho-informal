import vagas from './jobs.json' with {type: 'json'}
var divtela = document.getElementById('tela');
const dbMock = vagas;


const urlParams = new URLSearchParams(location.search);
var idCat = parseInt(urlParams.get('id'));


let str = '';
let number = 0
for (let i = 0; i < dbMock.vagas.length; i++) {
    let vaga = dbMock.vagas[i];
    if (idCat == idCat) {
        console.log(idCat);
        str = `<div class="card text-center mx-auto mt-40px"  style="width: 18rem;">            
    <div class="card-body">
        <h5 class="card-title">${vaga.nome_vaga}</h5>
        <p class="card-text"><b>Senioridade:</b> ${vaga.Categoria} <br> <b>Descricao:</b> ${vaga.Descricao} <br> <b>Localidade:</b> ${vaga.Location}</p>
                        
    </div>
</div>`
    }
}
divtela.innerHTML = (`${str}`)








