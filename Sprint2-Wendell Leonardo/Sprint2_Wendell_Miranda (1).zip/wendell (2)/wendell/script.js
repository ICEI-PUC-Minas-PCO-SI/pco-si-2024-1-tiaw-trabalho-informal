const saveButtons = document.querySelectorAll('.btn-save');
const metaInputs = document.querySelectorAll('#metaInput');
const dataInputs = document.querySelectorAll('#dataInput');
const rangeInputs = document.querySelectorAll('#range');
const deleteButtons = document.querySelectorAll('.btn-delete');

rangeInputs[0].value = 100;
rangeInputs[1].value = 100;
rangeInputs[2].value = 100;
rangeInputs[3].value = 100;

saveButtons.forEach((saveButton, index) => {
  saveButton.addEventListener('click', () => {
    const meta = metaInputs[index].value;
    const data = dataInputs[index].value;
    const range = rangeInputs[index].value;

    const dataToSave = { meta, data, range };
    const jsonData = JSON.stringify(dataToSave);

    localStorage.setItem(`savedData${index + 1}`, jsonData);

    metaInputs[index].value = meta;
    dataInputs[index].value = data;
    rangeInputs[index].value = range;
  });
});

for (let i = 0; i < 4; i++) {
  const savedData = localStorage.getItem(`savedData${i + 1}`);

  if (savedData) {
    const parsedData = JSON.parse(savedData);
    metaInputs[i].value = parsedData.meta;
    dataInputs[i].value = parsedData.data;
    rangeInputs[i].value = parsedData.range;
  }
}

deleteButtons.forEach((deleteButton, index) => {
  deleteButton.addEventListener('click', () => {
    metaInputs[index].value = '';
    dataInputs[index].value = '';
    rangeInputs[index].value = 100; 

    localStorage.removeItem(`savedData${index + 1}`);
    rangeValueSpans[index].textContent = rangeInputs[index].value;
  });
});
const rangeValueSpans = document.querySelectorAll(".rangeValue");

rangeInputs.forEach((rangeInput, index) => {
  
  rangeValueSpans[index].textContent = rangeInput.value;
  console.log("teste");
  rangeInput.addEventListener("input", () => {
    rangeValueSpans[index].textContent = rangeInput.value;
    
  });
});


