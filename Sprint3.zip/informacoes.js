document.getElementById('changeImage').addEventListener('click', () => {
    document.getElementById('uploadImage').click();
});

document.getElementById('uploadImage').addEventListener('change', (event) => {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            document.getElementById('profileImage').src = e.target.result;
            localStorage.setItem('profileImage', e.target.result);
        };
        reader.readAsDataURL(file);
    }
});

document.querySelector('#profile-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const name = document.querySelector('#name').value;
    const interest = document.querySelector('#interest').value;
    const education = document.querySelector('#education').value;
    const experience = document.querySelector('#experience').value;
    const skills = document.querySelector('#skills').value;
    
    const informacoesData = {
        "informacoesPessoais": {
            "nome": name,
            "areaDeInteresse": interest,
            "educacaoEQualificacoes": education,
            "resumoProfissional": experience,
            "habilidadesCompetencias": skills
        }
    };
    localStorage.setItem('informacoesData', JSON.stringify(informacoesData));
    window.location.href = 'perfil.html';
});
