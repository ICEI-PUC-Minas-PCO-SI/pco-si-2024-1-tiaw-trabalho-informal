document.addEventListener('DOMContentLoaded', function() {
    const perfilData = JSON.parse(localStorage.getItem('informacoesData'));

    if (perfilData) {
        document.getElementById('profile-name').textContent = perfilData.informacoesPessoais.nome;
        document.getElementById('profile-education').textContent = perfilData.informacoesPessoais.educacaoEQualificacoes;
        document.getElementById('profile-summary').textContent = perfilData.informacoesPessoais.resumoProfissional;
    }

    const profileImage = localStorage.getItem('profileImage');
    if (profileImage) {
        document.getElementById('profileImage').src = profileImage;
    }

    document.getElementById('edit-profile-button').addEventListener('click', function() {
        window.location.href = 'informacoes.html';
    });
});
