var profile = localStorage.getItem('profile');

if (profile) {
    document.getElementById('userButtons').style.display = 'none';
    document.getElementById('profileIcon').style.display = 'block';
}
