document.getElementById("loginForm").addEventListener("submit", function(event) {
  event.preventDefault(); 

  var email = document.getElementById("email").value;
  var password = document.getElementById("password").value;
  var confirmPassword = document.getElementById("confirmPassword").value;
  var formData = {
    "email": email,
    "password": password,
    "confirmPassword": confirmPassword
  };

  var jsonData = JSON.stringify(formData);
  localStorage.setItem('formData', jsonData);
  localStorage.setItem('profile', 'created');
  window.location.href = "index.html";
});
