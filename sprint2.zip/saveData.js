function getData() {
  
  var jsonData = localStorage.getItem('formData');
  var formData = JSON.parse(jsonData);

  console.log("Dados salvos:");
  console.log(formData);
}
