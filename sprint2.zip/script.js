document.addEventListener("DOMContentLoaded", function () {
    const tarefaInput = document.getElementById("tarefaInput");
    const botaoAdicionarTarefa = document.getElementById("botaoAdicionarTarefa");
    const listaDeTarefas = document.getElementById("listaDeTarefas");

    function carregarTarefas() {
        const tarefas = JSON.parse(localStorage.getItem("tarefas")) || [];
        tarefas.forEach(tarefa => {
            adicionarTarefaNaLista(tarefa);
        });
    }

    function adicionarTarefaNaLista(textoDaTarefa) {
        const itemDaTarefa = document.createElement("div");
        itemDaTarefa.classList.add("itemDaTarefa");
        itemDaTarefa.innerHTML = `
            <input type="checkbox">
            <span>${textoDaTarefa}</span>
            <button class="botaoRemoverTarefa">Remover</button>
        `;
        listaDeTarefas.appendChild(itemDaTarefa);
    }

    function salvarTarefas() {
        const tarefas = Array.from(document.querySelectorAll(".itemDaTarefa span")).map(tarefa => tarefa.textContent);
        localStorage.setItem("tarefas", JSON.stringify(tarefas));
    }

    carregarTarefas();

    botaoAdicionarTarefa.addEventListener("click", function () {
        const textoDaTarefa = tarefaInput.value.trim();
        if (textoDaTarefa !== "") {
            adicionarTarefaNaLista(textoDaTarefa);
            salvarTarefas();
            tarefaInput.value = "";
        }
    });

    listaDeTarefas.addEventListener("click", function (event) {
        if (event.target.classList.contains("botaoRemoverTarefa")) {
            const itemDaTarefa = event.target.parentElement;
            itemDaTarefa.remove();
            salvarTarefas();
        }
    });

    listaDeTarefas.addEventListener("change", function (event) {
        if (event.target.type === "checkbox") {
            const itemDaTarefa = event.target.parentElement;
            itemDaTarefa.classList.toggle("concluida");
            salvarTarefas();
        }
    });
});
